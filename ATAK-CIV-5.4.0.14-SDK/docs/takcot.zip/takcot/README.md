This repository is for the XSD definitions for all TAK CoT communication.   As new details are defined, they will be documented here is XSD form for agreeement between all of the TAK systems.
For reference purposes, this repository also contains the base CoT definitions in XSD from MITRE.
